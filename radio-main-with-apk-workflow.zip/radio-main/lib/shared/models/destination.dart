import 'package:explorer_os_mobile/core/data/model.dart';

/// A read-only representation of an ExplorerOS destination — the top-level unit
/// of content (e.g. a national park, region, or route).
///
/// Destinations (National Park Buddy, Florida Buddy, Historic Route 66, and any
/// future ones) are NEVER hardcoded. This model describes the shape of a
/// destination record returned by the backend (Supabase) so the UI has a
/// type-safe object to render. It is immutable and only knows how to be created
/// *from* backend JSON — reflecting the read-only nature of the mobile client.
/// Implements [Model] so the generic repository/cache can manage it uniformly.
///
/// All fields beyond [id]/[name] are optional so the UI degrades gracefully when
/// the backend omits them (e.g. a row without a category or image).
class Destination implements Model {
  const Destination({
    required this.id,
    required this.name,
    this.description,
    this.imageUrl,
    this.location,
    this.category,
    this.featured = false,
    this.distanceLabel,
    this.latitude,
    this.longitude,
  });

  @override
  final String id;
  final String name;
  final String? description;
  final String? imageUrl;

  /// Coordinates (Base44 `latitude`/`longitude`), used to plot the destination
  /// on the map. Null when the backend omits them.
  final double? latitude;
  final double? longitude;

  /// True when both coordinates are present (i.e. the destination is mappable).
  bool get hasCoordinates => latitude != null && longitude != null;

  /// Human-readable location line (e.g. "Ocala, Florida"), shown as a subtitle.
  final String? location;

  /// Backend category token used by the Explore filters (e.g. "park", "trail",
  /// "scenic"). See [DestinationCategory].
  final String? category;

  /// Whether this destination should be highlighted in the Featured section.
  final bool featured;

  /// Optional pre-computed distance label (e.g. "12 mi"). Supplied by the
  /// backend for now; will be computed live once the GPS feature ships.
  final String? distanceLabel;

  /// Builds a [Destination] from a backend JSON map. Missing/renamed keys are
  /// handled defensively so one malformed row cannot crash the app.
  ///
  /// Maps the Base44 `destinations` schema (source of truth): `destination_id`,
  /// `hero_image`, `destination_type`, `state_province`/`country`, `featured`.
  /// Legacy keys (`id`, `image_url`, `location`, `category`, `is_featured`) are
  /// kept as fallbacks so seed/preview data still loads unchanged.
  factory Destination.fromJson(Map<String, dynamic> json) {
    return Destination(
      id: (json['destination_id'] ?? json['id'])?.toString() ?? '',
      name: (json['name'] ?? '') as String,
      description: json['description'] as String?,
      imageUrl: (json['hero_image'] ?? json['image_url']) as String?,
      location: (json['location'] as String?) ?? _composeLocation(json),
      category: (json['destination_type'] ?? json['category']) as String?,
      featured: (json['featured'] ?? json['is_featured'] ?? false) as bool,
      distanceLabel: json['distance_label'] as String?,
      latitude: (json['latitude'] as num?)?.toDouble(),
      longitude: (json['longitude'] as num?)?.toDouble(),
    );
  }

  /// Builds a human-readable location line from Base44's separate
  /// `state_province` / `country` columns (e.g. "Florida, USA").
  static String? _composeLocation(Map<String, dynamic> json) {
    final parts = [json['state_province'], json['country']]
        .whereType<String>()
        .where((s) => s.trim().isNotEmpty)
        .toList(growable: false);
    return parts.isEmpty ? null : parts.join(', ');
  }
}
