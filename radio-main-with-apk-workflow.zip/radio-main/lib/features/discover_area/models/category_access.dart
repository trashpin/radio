import 'package:explorer_os_mobile/features/discover_area/models/discovery_area.dart';

/// Which stage of the History/Nature/Geology access check the traveler is
/// at. Named explicitly (rather than just a bool) so the UI can show a
/// distinct, honest message for each — this is the audited requirement:
/// "no Area found" must never look the same as "outside the radius".
enum CategoryAccessStage {
  ready,
  noAreaFound,
  areaInactive,
  outsideRadius,
}

/// Result of [checkAreaCategoryAccess] — a stage plus the exact message the
/// UI should show verbatim (no separate "translate this" step needed).
class CategoryAccessResult {
  const CategoryAccessResult(this.stage, this.message);
  final CategoryAccessStage stage;
  final String message;
  bool get isReady => stage == CategoryAccessStage.ready;
}

/// Gate for opening History/Nature/Geology from the Discover Screen. Checks,
/// in order:
///  1. Was an Area found at all for the traveler's current GPS position?
///  2. Is that Area active (not disabled/hidden)?
///  3. Is the traveler actually INSIDE the Area's detection radius — not
///     just near it (the Discover Screen itself can show a "nearby, not
///     inside" area via its fallback-distance behavior; opening narrated,
///     GPS-gated content requires actually being inside)?
///
/// Pure — no I/O, no Riverpod — easy to unit test independently of GPS.
CategoryAccessResult checkAreaCategoryAccess(DiscoveryArea? area) {
  if (area == null) {
    return const CategoryAccessResult(
      CategoryAccessStage.noAreaFound,
      'No area was found at your current location — GPS could not match '
      'you to a mapped area here.',
    );
  }
  if (!area.location.active || area.location.hidden) {
    return CategoryAccessResult(
      CategoryAccessStage.areaInactive,
      '${area.name} is not currently active.',
    );
  }
  if (!area.isCurrentlyInside) {
    return CategoryAccessResult(
      CategoryAccessStage.outsideRadius,
      "You're near ${area.name}, but not yet inside its detection radius — "
      'get a little closer to unlock this.',
    );
  }
  return const CategoryAccessResult(CategoryAccessStage.ready, '');
}
