import 'package:flutter_test/flutter_test.dart';

import 'package:explorer_os_mobile/features/discover_area/models/category_access.dart';
import 'package:explorer_os_mobile/features/discover_area/models/discovery_area.dart';
import 'package:explorer_os_mobile/features/locations/models/master_location.dart';

DiscoveryArea _area({
  double distanceMeters = 0,
  double radius = 500,
  bool active = true,
  bool hidden = false,
}) =>
    DiscoveryArea(
      location: MasterLocation.fromJson({
        'id': '1',
        'name': 'Historic Downtown Ocala',
        'category': 'area',
        'latitude': 29.2,
        'longitude': -82.1,
        'trigger_radius': radius,
        'active': active,
        'hidden': hidden,
      }),
      distanceMeters: distanceMeters,
    );

void main() {
  group('checkAreaCategoryAccess', () {
    test('null area -> noAreaFound, with an honest GPS-specific message', () {
      final result = checkAreaCategoryAccess(null);
      expect(result.stage, CategoryAccessStage.noAreaFound);
      expect(result.isReady, isFalse);
      expect(result.message, contains('GPS'));
    });

    test('inactive area -> areaInactive', () {
      final result = checkAreaCategoryAccess(_area(active: false));
      expect(result.stage, CategoryAccessStage.areaInactive);
      expect(result.isReady, isFalse);
    });

    test('hidden area -> areaInactive', () {
      final result = checkAreaCategoryAccess(_area(hidden: true));
      expect(result.stage, CategoryAccessStage.areaInactive);
    });

    test('active area but traveler outside the radius -> outsideRadius', () {
      final result = checkAreaCategoryAccess(
        _area(distanceMeters: 1000, radius: 500),
      );
      expect(result.stage, CategoryAccessStage.outsideRadius);
      expect(result.isReady, isFalse);
      expect(result.message, contains('Historic Downtown Ocala'));
    });

    test('active area and traveler inside the radius -> ready', () {
      final result = checkAreaCategoryAccess(
        _area(distanceMeters: 100, radius: 500),
      );
      expect(result.stage, CategoryAccessStage.ready);
      expect(result.isReady, isTrue);
    });

    test('exactly at the radius boundary counts as inside (<=, not <)', () {
      final result = checkAreaCategoryAccess(
        _area(distanceMeters: 500, radius: 500),
      );
      expect(result.isReady, isTrue);
    });

    test('every non-ready stage has a distinct, non-empty message', () {
      final noArea = checkAreaCategoryAccess(null);
      final inactive = checkAreaCategoryAccess(_area(active: false));
      final outside = checkAreaCategoryAccess(_area(distanceMeters: 999999));

      final messages = {noArea.message, inactive.message, outside.message};
      expect(messages, hasLength(3)); // all different from each other
      for (final m in messages) {
        expect(m.trim(), isNotEmpty);
      }
    });
  });
}
