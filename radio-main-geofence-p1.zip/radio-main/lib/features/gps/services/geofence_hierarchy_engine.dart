import 'package:explorer_os_mobile/features/gps/models/geofence.dart';
import 'package:explorer_os_mobile/features/gps/utils/geo_math.dart';

/// Finds every [Geofence] whose circle contains ([latitude], [longitude]),
/// sorted deepest-first ([GeofenceLevel.depth] descending) — this is the
/// "deepest boundary always wins" ordering. Only [active] geofences are
/// considered.
///
/// Circle-only (no polygon) — see migration 0043's doc comment for why
/// that's deliberate for this phase. Reuses the exact same distance
/// function [LocationTriggerEngine] already uses, so the containment math
/// stays identical across the whole GPS system rather than a second
/// implementation drifting from it.
///
/// Pure — no I/O, no stored state — easy to unit test and safe to call on
/// every GPS tick without side effects.
List<GeofenceMatch> containingGeofences(
  List<Geofence> all,
  double latitude,
  double longitude,
) {
  final matches = <GeofenceMatch>[];
  for (final g in all) {
    if (!g.active) continue;
    final distance = GeoMath.distanceMeters(
      latitude,
      longitude,
      g.centerLat,
      g.centerLng,
    );
    if (distance <= g.radiusMeters) {
      matches.add(GeofenceMatch(geofence: g, distanceMeters: distance));
    }
  }
  matches.sort((a, b) => b.level.depth.compareTo(a.level.depth));
  return matches;
}

/// Picks the ONE geofence that should currently narrate, from every
/// geofence the traveler is inside right now (see [containingGeofences]).
///
///  1. The deepest level always wins outright — a County is never chosen
///     over a POI the traveler is standing inside, no matter what
///     priority says.
///  2. Among geofences AT that same deepest level (e.g. two overlapping
///     POIs), [GeofenceMatch.effectivePriority] breaks the tie.
///  3. A remaining tie (identical priority) is broken by proximity — the
///     nearer center wins, so the result is always deterministic.
///
/// Pure. Returns null only when [containing] is empty.
GeofenceMatch? resolveActiveGeofence(List<GeofenceMatch> containing) {
  if (containing.isEmpty) return null;

  final deepestLevel = containing
      .map((m) => m.level.depth)
      .reduce((a, b) => a > b ? a : b);
  final atDeepest = containing.where((m) => m.level.depth == deepestLevel);

  return atDeepest.reduce((a, b) {
    if (a.effectivePriority != b.effectivePriority) {
      return a.effectivePriority > b.effectivePriority ? a : b;
    }
    return a.distanceMeters <= b.distanceMeters ? a : b;
  });
}

/// Walks [geofence]'s `parent_id` chain up to the root, closest-parent
/// first (immediate parent, then grandparent, ...). Stops early (rather
/// than looping forever) if a cycle is somehow present in the data —
/// admin-entered parent links should never form one, but this makes that
/// a safe no-op instead of a hang.
List<Geofence> ancestorChain(Geofence geofence, List<Geofence> all) {
  final byId = {for (final g in all) g.id: g};
  final chain = <Geofence>[];
  final seen = <String>{geofence.id};

  var current = geofence;
  while (current.parentId != null) {
    final parent = byId[current.parentId];
    if (parent == null || !seen.add(parent.id)) break; // missing or cycle
    chain.add(parent);
    current = parent;
  }
  return chain;
}
