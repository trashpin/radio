import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:explorer_os_mobile/features/gps/data/geofence_repository.dart';
import 'package:explorer_os_mobile/features/gps/models/geofence.dart';
import 'package:explorer_os_mobile/features/gps/services/geofence_hierarchy_engine.dart';
import 'package:explorer_os_mobile/features/maps/providers/nearby_provider.dart';

/// Every geofence the traveler is currently inside, deepest-first — the
/// live version of [containingGeofences], recomputed whenever GPS position
/// or the geofence list changes. Empty (not null) when they're inside
/// nothing.
final currentGeofenceMatchesProvider = Provider<List<GeofenceMatch>>((ref) {
  final center = ref.watch(mapCenterProvider);
  if (center == null) return const [];
  final all = ref.watch(geofencesProvider).value ?? const [];
  return containingGeofences(all, center.latitude, center.longitude);
});

/// The single geofence that should currently be narrating, per the
/// priority resolver — null when the traveler is inside nothing (or no
/// GPS fix yet).
final activeGeofenceProvider = Provider<GeofenceMatch?>((ref) {
  final containing = ref.watch(currentGeofenceMatchesProvider);
  return resolveActiveGeofence(containing);
});
