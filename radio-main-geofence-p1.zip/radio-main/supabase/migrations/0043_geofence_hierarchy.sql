-- ExplorerOS — Discovery Engine, Phase 1: geofence hierarchy schema.
--
-- A "geofence" is deliberately a NEW table, not a redesign of `locations`.
-- `locations` stays exactly what it already is (the content registry —
-- name, images, narration, category); `geofences` holds the *shape*
-- (circle today; polygon is a later phase) and the *hierarchy*
-- (parent_id), referencing `locations.id` for its content — the same
-- pattern `area_discovery_content` already uses to attach to a location
-- without touching the `locations` table.
--
-- Circle-only in this migration on purpose (see the architecture doc,
-- Section 9, phase 1): polygon support needs PostGIS and a real map-drawing
-- admin UI, both scoped to a later phase. This phase is the parent-chain
-- hierarchy + priority resolution, which only needs a center point and a
-- radius — exactly the shape `locations.trigger_radius` already uses.
--
-- Idempotent: safe to re-run.

create extension if not exists "pgcrypto";

do $$
begin
  if not exists (select 1 from pg_type where typname = 'geofence_level') then
    create type geofence_level as enum (
      'state', 'county', 'city', 'district', 'neighborhood',
      'park', 'historic_site', 'museum', 'trail', 'business', 'poi'
    );
  end if;
end $$;

-- Default cross-type priority per level (POI beats Museum beats Park...).
-- A specific geofence can override via geofences.priority_override; within
-- the same level, locations.priority (already exists) is the tiebreaker —
-- unchanged, same as it already works today.
create table if not exists public.geofence_level_defaults (
  level            geofence_level primary key,
  default_priority integer not null
);
insert into public.geofence_level_defaults (level, default_priority) values
  ('poi', 100), ('museum', 95), ('historic_site', 90), ('trail', 85),
  ('business', 82), ('park', 80), ('neighborhood', 70), ('district', 65),
  ('city', 60), ('county', 40), ('state', 20)
on conflict (level) do nothing;

create table if not exists public.geofences (
  id                uuid primary key default gen_random_uuid(),
  location_id       uuid not null references public.locations(id) on delete cascade,
  level             geofence_level not null,
  parent_id         uuid references public.geofences(id) on delete set null,

  center_lat        double precision not null,
  center_lng        double precision not null,
  radius_meters     double precision not null,

  priority_override integer,
  active            boolean not null default true,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

create index if not exists geofences_location_idx on public.geofences (location_id);
create index if not exists geofences_parent_idx on public.geofences (parent_id);
create index if not exists geofences_level_idx on public.geofences (level);
create index if not exists geofences_active_idx on public.geofences (active);

create or replace function public.geofences_touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

drop trigger if exists geofences_set_updated_at on public.geofences;
create trigger geofences_set_updated_at
  before update on public.geofences
  for each row execute function public.geofences_touch_updated_at();

alter table public.geofences enable row level security;
alter table public.geofence_level_defaults enable row level security;
do $$
begin
  execute 'drop policy if exists "geofences_read" on public.geofences';
  execute 'create policy "geofences_read" on public.geofences for select to anon, authenticated using (true)';
  execute 'drop policy if exists "geofences_write" on public.geofences';
  execute 'create policy "geofences_write" on public.geofences for insert to anon, authenticated with check (true)';
  execute 'drop policy if exists "geofences_update" on public.geofences';
  execute 'create policy "geofences_update" on public.geofences for update to anon, authenticated using (true) with check (true)';
  execute 'drop policy if exists "geofences_delete" on public.geofences';
  execute 'create policy "geofences_delete" on public.geofences for delete to anon, authenticated using (true)';

  execute 'drop policy if exists "geofence_level_defaults_read" on public.geofence_level_defaults';
  execute 'create policy "geofence_level_defaults_read" on public.geofence_level_defaults for select to anon, authenticated using (true)';
end $$;
