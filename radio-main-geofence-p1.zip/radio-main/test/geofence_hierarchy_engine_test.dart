import 'package:flutter_test/flutter_test.dart';

import 'package:explorer_os_mobile/features/gps/models/geofence.dart';
import 'package:explorer_os_mobile/features/gps/models/geofence_level.dart';
import 'package:explorer_os_mobile/features/gps/services/geofence_hierarchy_engine.dart';

Geofence _fence({
  required String id,
  required GeofenceLevel level,
  String? parentId,
  double lat = 29.2,
  double lng = -82.1,
  double radius = 1000,
  int? priorityOverride,
  bool active = true,
}) =>
    Geofence(
      id: id,
      locationId: 'loc-$id',
      level: level,
      parentId: parentId,
      centerLat: lat,
      centerLng: lng,
      radiusMeters: radius,
      priorityOverride: priorityOverride,
      active: active,
    );

void main() {
  group('GeofenceLevel', () {
    test('depth strictly increases from state to poi, matching the spec '
        'hierarchy', () {
      final ordered = [
        GeofenceLevel.state,
        GeofenceLevel.county,
        GeofenceLevel.city,
        GeofenceLevel.district,
        GeofenceLevel.neighborhood,
        GeofenceLevel.park,
        GeofenceLevel.business,
        GeofenceLevel.trail,
        GeofenceLevel.historicSite,
        GeofenceLevel.museum,
        GeofenceLevel.poi,
      ];
      for (var i = 1; i < ordered.length; i++) {
        expect(ordered[i].depth, greaterThan(ordered[i - 1].depth));
      }
    });

    test('default priorities match the spec numbers', () {
      expect(GeofenceLevel.poi.defaultPriority, 100);
      expect(GeofenceLevel.museum.defaultPriority, 95);
      expect(GeofenceLevel.historicSite.defaultPriority, 90);
      expect(GeofenceLevel.park.defaultPriority, 80);
      expect(GeofenceLevel.city.defaultPriority, 60);
      expect(GeofenceLevel.county.defaultPriority, 40);
      expect(GeofenceLevel.state.defaultPriority, 20);
    });

    test('fromId round-trips every level, and is null for garbage', () {
      for (final level in GeofenceLevel.values) {
        expect(GeofenceLevel.fromId(level.id), level);
      }
      expect(GeofenceLevel.fromId('not_a_level'), isNull);
      expect(GeofenceLevel.fromId(null), isNull);
    });
  });

  group('containingGeofences', () {
    test('returns only geofences whose circle actually contains the point',
        () {
      final near = _fence(id: 'near', level: GeofenceLevel.poi, radius: 200);
      final far = _fence(
        id: 'far',
        level: GeofenceLevel.poi,
        lat: 30.0,
        radius: 200,
      );
      final result = containingGeofences([near, far], 29.2, -82.1);
      expect(result.map((m) => m.geofence.id), ['near']);
    });

    test('sorts results deepest-first — a POI before a County it is also '
        'inside', () {
      final county = _fence(id: 'county', level: GeofenceLevel.county, radius: 50000);
      final poi = _fence(id: 'poi', level: GeofenceLevel.poi, radius: 200);
      final result = containingGeofences([county, poi], 29.2, -82.1);
      expect(result.map((m) => m.geofence.id), ['poi', 'county']);
    });

    test('inactive geofences are never returned even if they contain the '
        'point', () {
      final inactive =
          _fence(id: 'inactive', level: GeofenceLevel.poi, active: false);
      final result = containingGeofences([inactive], 29.2, -82.1);
      expect(result, isEmpty);
    });

    test('empty geofence list returns empty, no errors', () {
      expect(containingGeofences(const [], 29.2, -82.1), isEmpty);
    });
  });

  group('resolveActiveGeofence', () {
    test('null with no containing geofences', () {
      expect(resolveActiveGeofence(const []), isNull);
    });

    test('deepest level always wins over a shallower one, regardless of '
        'priority', () {
      // A County with an artificially huge priority override still loses
      // to a POI, because depth is checked first.
      final county = GeofenceMatch(
        geofence: _fence(
          id: 'county',
          level: GeofenceLevel.county,
          priorityOverride: 999,
        ),
        distanceMeters: 10,
      );
      final poi = GeofenceMatch(
        geofence: _fence(id: 'poi', level: GeofenceLevel.poi),
        distanceMeters: 10,
      );
      final result = resolveActiveGeofence([county, poi]);
      expect(result?.geofence.id, 'poi');
    });

    test('among same-depth geofences, higher effective priority wins', () {
      final low = GeofenceMatch(
        geofence: _fence(id: 'low', level: GeofenceLevel.poi, priorityOverride: 50),
        distanceMeters: 10,
      );
      final high = GeofenceMatch(
        geofence: _fence(id: 'high', level: GeofenceLevel.poi, priorityOverride: 150),
        distanceMeters: 10,
      );
      final result = resolveActiveGeofence([low, high]);
      expect(result?.geofence.id, 'high');
    });

    test('a tied priority at the same depth is broken by proximity', () {
      final farther = GeofenceMatch(
        geofence: _fence(id: 'farther', level: GeofenceLevel.poi),
        distanceMeters: 300,
      );
      final closer = GeofenceMatch(
        geofence: _fence(id: 'closer', level: GeofenceLevel.poi),
        distanceMeters: 50,
      );
      final result = resolveActiveGeofence([farther, closer]);
      expect(result?.geofence.id, 'closer');
    });

    test('uses each level\'s own default priority when no override is set',
        () {
      // Two DIFFERENT levels at the same depth never happens in practice
      // (depth is 1:1 with level) — this instead checks that a Museum
      // (default 95) with no override beats a hypothetical same-level
      // sibling with an explicit lower override.
      final noOverride = GeofenceMatch(
        geofence: _fence(id: 'a', level: GeofenceLevel.museum),
        distanceMeters: 10,
      );
      final lowerOverride = GeofenceMatch(
        geofence:
            _fence(id: 'b', level: GeofenceLevel.museum, priorityOverride: 10),
        distanceMeters: 10,
      );
      final result = resolveActiveGeofence([noOverride, lowerOverride]);
      expect(result?.geofence.id, 'a');
    });
  });

  group('ancestorChain', () {
    test('walks parent_id up to the root, closest-parent first', () {
      final state = _fence(id: 'state', level: GeofenceLevel.state);
      final county =
          _fence(id: 'county', level: GeofenceLevel.county, parentId: 'state');
      final city =
          _fence(id: 'city', level: GeofenceLevel.city, parentId: 'county');
      final poi =
          _fence(id: 'poi', level: GeofenceLevel.poi, parentId: 'city');

      final chain = ancestorChain(poi, [state, county, city, poi]);
      expect(chain.map((g) => g.id), ['city', 'county', 'state']);
    });

    test('a geofence with no parent has an empty chain', () {
      final top = _fence(id: 'top', level: GeofenceLevel.state);
      expect(ancestorChain(top, [top]), isEmpty);
    });

    test('a missing parent id stops the walk instead of throwing', () {
      final orphan = _fence(
        id: 'orphan',
        level: GeofenceLevel.poi,
        parentId: 'does-not-exist',
      );
      expect(ancestorChain(orphan, [orphan]), isEmpty);
    });

    test('a cycle in the data stops the walk instead of looping forever',
        () {
      final a = _fence(id: 'a', level: GeofenceLevel.city, parentId: 'b');
      final b = _fence(id: 'b', level: GeofenceLevel.county, parentId: 'a');
      final chain = ancestorChain(a, [a, b]);
      // Should terminate (not hang) and not include 'a' again.
      expect(chain.where((g) => g.id == 'a'), isEmpty);
    });
  });
}
